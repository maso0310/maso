from supercv import *

img_path = r'G:\水稻\1101\1101手機影像處理\1_original\IMG_4201.png'

calculator_HMC(img_path)