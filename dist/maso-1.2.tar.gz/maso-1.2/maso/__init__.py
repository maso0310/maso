from .supercv import *
from .superos import *
from .AI_model import *


print('''
功能列表：
showimg_by_path(image_path):輸入圖片路徑直接看圖片
showimg_by_ndarray(image):輸入圖片矩陣直接看圖片
''')
