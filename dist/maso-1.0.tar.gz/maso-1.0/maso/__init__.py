from supercv import *

print('''
功能列表：
supercv:
1.showimg_by_path(image_path):輸入圖片路徑直接看圖片
2.showimg_by_ndarray(image):輸入圖片矩陣直接看圖片
''')

def test():
    print('這個是Maso專用的package')
